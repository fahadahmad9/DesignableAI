# prompt_builder.py
from typing import Dict, Any, Optional, List
import json

# Import your per-chair summaries here
# Create a file called chair_summaries.py with: CHAIR_SUMMARIES = {...}
from chair_summaries import CHAIR_SUMMARIES


# -----------------------------------------
# 1. SYSTEM PROMPT (Your full design-partner prompt)
# -----------------------------------------
SYSTEM_PROMPT = """
You are “Designable AI,” a senior furniture design specialist. Your job is to interpret 2D chair sketches with measurements and help the designer refine their concept. You speak with a calm, intelligent, collaborative tone.

Your responses must ALWAYS follow this structure:

1. Interpretation of the user’s drawing — Explain clearly what you understood.
2. Key design considerations — Ergonomics, structure, materials, aesthetics.
3. Questions for deeper refinement — Ask 3–6 specific questions that help evolve the design.
4. Suggested next step (one step only) — Give a small recommendation, but never complete the entire design at once.

You must maintain long, thoughtful, iterative conversations. Never jump to final answers. Never assume missing details — instead ask for clarification.

Encourage creativity, technical precision, and design exploration.
"""


# -----------------------------------------
# 2. RULE-BASED CONFIDENCE HEURISTIC
# -----------------------------------------
EXPECTED_PARTS = {
    "Eames Lounge Chair": {"eames_lounge_cushion", "eames_base", "headrest", "backrest", "seat"},
    "Ergonomic Office Chair": {"five_star_base", "caster_wheel", "control_mechanism", "lumbar_support", "backrest"},
    "Sofa Chair": {"sofa_armrest", "seat", "backrest"},
    "Egg Chair": {"armrest_egg", "seat", "backrest"},
    "Armchair": {"armrest", "seat", "backrest"},
}


def compute_rule_confidence(pred_type: str, parts: List[str]) -> float:
    """
    Simple heuristic:
    (matching expected parts) / (expected parts)
    If unknown type → fallback heuristic using number of parts.
    """
    part_set = set(parts)
    expected = EXPECTED_PARTS.get(pred_type)

    if expected:
        match = len(part_set & expected)
        return round(match / max(1, len(expected)), 2)

    # fallback confidence for unknown types
    if len(parts) >= 4:
        return 0.7
    return round(min(1.0, len(parts) / 3.0), 2)


# -----------------------------------------
# 3. PROMPT BUILDER
# -----------------------------------------
def build_prompt_from_classifier_result(
    classifier_result: Dict[str, Any],
    tone: str = "Senior Furniture Design Consultant",
    user_message: Optional[str] = None,
    ask_clarifying_on_low_conf: bool = True,
    low_conf_threshold: float = 0.7
) -> Dict[str, Any]:
    """
    Builds the full LLaMA prompt using:
      - classifier output
      - chair summary (from CHAIR_SUMMARIES)
      - your structured instructions
    """

    canonical_parts = classifier_result.get("canonical_parts", [])
    predicted_type = classifier_result.get("identified_type", "Unknown Chair Type")
    image_id = classifier_result.get("image_id", "uploaded_image")

    # Compute confidence score
    rule_conf = compute_rule_confidence(predicted_type, canonical_parts)

    # Create compact string for parts
    parts_str = ", ".join(canonical_parts) if canonical_parts else "none"

    # Notes for LLaMA
    notes = []
    if rule_conf < low_conf_threshold:
        notes.append(f"low_rule_confidence({rule_conf})")
    if not canonical_parts:
        notes.append("no_detected_parts")
    notes_str = "; ".join(notes) if notes else "none"

    # Fetch custom summary for this chair type
    custom_summary = CHAIR_SUMMARIES.get(predicted_type, "").strip()

    # -----------------------------------------
    # USER PROMPT CONTENT FOR LLaMA
    # -----------------------------------------
    prompt_lines = []

    # System prompt first
    prompt_lines.append(SYSTEM_PROMPT.strip())
    prompt_lines.append("\n---\n")

    # Structured context block
    prompt_lines.append("Context (structured):")
    prompt_lines.append(f"- Image ID: {image_id}")
    prompt_lines.append(f"- Predicted chair type: {predicted_type}")
    prompt_lines.append(f"- Detected canonical parts: {parts_str}")
    prompt_lines.append(f"- Rule confidence: {rule_conf}")
    prompt_lines.append(f"- Notes: {notes_str}")

    # Add the custom summary you will write in chair_summaries.py
    if custom_summary:
        prompt_lines.append("\nDesign summary (from the app, not user):")
        prompt_lines.append(custom_summary)

    # Include a user message if you pass one (optional)
    if user_message:
        prompt_lines.append("\nUser Request / Query:")
        prompt_lines.append(user_message.strip())

    # Assistant instructions (format enforced)
    prompt_lines.append("\nAssistant Instructions:")
    prompt_lines.append("Your response MUST follow this exact structure:")
    prompt_lines.append("1. Interpretation of the user’s drawing")
    prompt_lines.append("2. Key design considerations (bullet points)")
    prompt_lines.append("3. Questions for deeper refinement (3–6 questions)")
    prompt_lines.append("4. Suggested next step (ONE small recommendation only)")
    prompt_lines.append("\nTone:")
    prompt_lines.append(f"- {tone}")
    prompt_lines.append("- Collaborative, investigative, calm, expert.")
    prompt_lines.append("- Never provide final designs or full manufacturing instructions in one reply.")
    prompt_lines.append("- Always ask follow-up questions if confidence is low or information is missing.")

    # Combine into a single prompt string
    full_prompt = "\n".join(prompt_lines)

    # Return the final prompt + metadata
    return {
        "system_prompt": SYSTEM_PROMPT.strip(),
        "prompt": full_prompt,
        "metadata": {
            "predicted_type": predicted_type,
            "canonical_parts": canonical_parts,
            "rule_confidence": rule_conf,
            "notes": notes,
            "tone": tone,
        }
    }


# Quick test
if __name__ == "__main__":
    dummy = {
        "canonical_parts": ["eames_base", "eames_lounge_cushion", "seat", "backrest", "headrest"],
        "identified_type": "Eames Lounge Chair",
        "image_id": "test_img.jpg"
    }

    out = build_prompt_from_classifier_result(dummy)
    print(out["prompt"][:1200])
